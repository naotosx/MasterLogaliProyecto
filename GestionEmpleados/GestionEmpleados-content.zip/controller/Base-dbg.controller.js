sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (e) {
  return e.extend("MasterLogali.GestionEmpleados.controller.Base", {
    
  });
});
